import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

public class userRegistration {
    private JFrame frame;
    private JTextField nameField, mobileField;
    private JComboBox<String> dobDayBox, dobMonthBox, dobYearBox;
    private JTextField addressField;
    private JCheckBox termsCheckBox;
    private JButton submitButton, resetButton;
    private JTextArea displayArea;

    public userRegistration() {
        // Frame setup
        frame = new JFrame("User Registration Form");
        frame.setSize(700, 600);
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLayout(null);

        // Name field
        JLabel nameLabel = new JLabel("Name:");
        nameLabel.setBounds(50, 50, 100, 30);
        frame.add(nameLabel);
        nameField = new JTextField();
        nameField.setBounds(150, 50, 200, 30);
        frame.add(nameField);

        // Mobile field
        JLabel mobileLabel = new JLabel("Mobile:");
        mobileLabel.setBounds(50, 100, 100, 30);
        frame.add(mobileLabel);
        mobileField = new JTextField();
        mobileField.setBounds(150, 100, 200, 30);
        frame.add(mobileField);

        // Date of Birth (DOB) dropdowns
        JLabel dobLabel = new JLabel("DOB:");
        dobLabel.setBounds(50, 150, 100, 30);
        frame.add(dobLabel);
        String[] days = new String[31];
        for (int i = 0; i < 31; i++) days[i] = String.valueOf(i + 1);
        dobDayBox = new JComboBox<>(days);
        dobDayBox.setBounds(150, 150, 60, 30);
        String[] months = {"Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"};
        dobMonthBox = new JComboBox<>(months);
        dobMonthBox.setBounds(220, 150, 80, 30);
        String[] years = new String[100];
        for (int i = 0; i < 100; i++) years[i] = String.valueOf(1925 + i);
        dobYearBox = new JComboBox<>(years);
        dobYearBox.setBounds(310, 150, 70, 30);
        frame.add(dobDayBox);
        frame.add(dobMonthBox);
        frame.add(dobYearBox);

        // Address field
        JLabel addressLabel = new JLabel("Address:");
        addressLabel.setBounds(50, 200, 100, 30);
        frame.add(addressLabel);
        addressField = new JTextField();
        addressField.setBounds(150, 200, 200, 30);
        frame.add(addressField);

        // Terms and Conditions checkbox
        termsCheckBox = new JCheckBox("Accept Terms and Conditions");
        termsCheckBox.setBounds(50, 250, 300, 30);
        frame.add(termsCheckBox);

        // Submit button
        submitButton = new JButton("Submit");
        submitButton.setBounds(50, 300, 100, 30);
        frame.add(submitButton);

        // Reset button
        resetButton = new JButton("Reset");
        resetButton.setBounds(200, 300, 100, 30);
        frame.add(resetButton);

        // Display Area (right side)
        displayArea = new JTextArea();
        displayArea.setBounds(400, 50, 250, 300);
        displayArea.setEditable(false);
        displayArea.setBorder(BorderFactory.createLineBorder(Color.BLACK));
        frame.add(displayArea);

        // Action listeners
        submitButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                submitForm();
            }
        });
        resetButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                resetForm();
            }
        });

        frame.setVisible(true);
    }

    private void submitForm() {
        if (!termsCheckBox.isSelected()) {
            JOptionPane.showMessageDialog(frame, "Please accept the terms and conditions.");
            return;
        }
    
        String name = nameField.getText();
        String mobile = mobileField.getText();
    
        // Correctly format the date of birth
        String year = (String) dobYearBox.getSelectedItem();
        String month = String.format("%02d", dobMonthBox.getSelectedIndex() + 1); // Convert month to 2-digit format
        String day = (String) dobDayBox.getSelectedItem();
        String dob = year + "-" + month + "-" + day;
    
        String address = addressField.getText();
    
        // Update the display area with form data
        displayArea.setText("Registration Details:\n");
        displayArea.append("Name: " + name + "\n");
        displayArea.append("Mobile: " + mobile + "\n");
        displayArea.append("DOB: " + dob + "\n");
        displayArea.append("Address: " + address + "\n");
    
        try {
            // Connect to MySQL Server
            Connection connection = DriverManager.getConnection(
                "jdbc:mysql://localhost:3307/user_registration", 
                "root", 
                "1234"     
            );
    
            String query = "INSERT INTO users (name, mobile, dob, address) VALUES (?, ?, ?, ?)";
            PreparedStatement preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, name);
            preparedStatement.setString(2, mobile);
            preparedStatement.setString(3, dob); 
            preparedStatement.setString(4, address);
            preparedStatement.executeUpdate();
            JOptionPane.showMessageDialog(frame, "Registration Successful!");
            connection.close();
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(frame, "Database Error: " + ex.getMessage());
        }
    }
    

    private void resetForm() {
        nameField.setText("");
        mobileField.setText("");
        dobDayBox.setSelectedIndex(0);
        dobMonthBox.setSelectedIndex(0);
        dobYearBox.setSelectedIndex(0);
        addressField.setText("");
        termsCheckBox.setSelected(false);
        displayArea.setText("");
    }

    public static void main(String[] args) {
        new userRegistration();
    }
}
