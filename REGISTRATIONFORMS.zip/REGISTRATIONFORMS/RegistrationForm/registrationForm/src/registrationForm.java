import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class registrationForm extends JFrame {
    private JTextField txtID, txtName, txtAddress, txtContact;
    private JRadioButton rbtnMale, rbtnFemale;
    private JButton btnRegister, btnExit;
    private ButtonGroup genderGroup;
    private JTable table;
    private DefaultTableModel tableModel;

    public registrationForm() {
        // Initialize components
        setTitle("Registration Form");
        setLayout(null);

        JLabel lblID = new JLabel("ID:");
        JLabel lblName = new JLabel("Name:");
        JLabel lblGender = new JLabel("Gender:");
        JLabel lblAddress = new JLabel("Address:");
        JLabel lblContact = new JLabel("Contact:");

        txtID = new JTextField(15);
        txtName = new JTextField(15);
        txtAddress = new JTextField(15);
        txtContact = new JTextField(15);

        rbtnMale = new JRadioButton("Male");
        rbtnFemale = new JRadioButton("Female");
        genderGroup = new ButtonGroup();
        genderGroup.add(rbtnMale);
        genderGroup.add(rbtnFemale);

        btnRegister = new JButton("Register");
        btnExit = new JButton("Exit");

        // Table setup
        tableModel = new DefaultTableModel(new String[]{"ID", "Name", "Gender", "Address", "Contact"}, 0);
        table = new JTable(tableModel);
        JScrollPane scrollPane = new JScrollPane(table);

        // Set positions for components
        lblID.setBounds(20, 20, 100, 25);
        txtID.setBounds(120, 20, 150, 25);
        lblName.setBounds(20, 60, 100, 25);
        txtName.setBounds(120, 60, 150, 25);
        lblGender.setBounds(20, 100, 100, 25);
        rbtnMale.setBounds(120, 100, 70, 25);
        rbtnFemale.setBounds(200, 100, 80, 25);
        lblAddress.setBounds(20, 140, 100, 25);
        txtAddress.setBounds(120, 140, 150, 25);
        lblContact.setBounds(20, 180, 100, 25);
        txtContact.setBounds(120, 180, 150, 25);
        btnRegister.setBounds(20, 220, 100, 30);
        btnExit.setBounds(140, 220, 100, 30);
        scrollPane.setBounds(300, 20, 450, 230); // Table moved to the right

        // Add components to frame
        add(lblID);
        add(txtID);
        add(lblName);
        add(txtName);
        add(lblGender);
        add(rbtnMale);
        add(rbtnFemale);
        add(lblAddress);
        add(txtAddress);
        add(lblContact);
        add(txtContact);
        add(btnRegister);
        add(btnExit);
        add(scrollPane);

        // Button actions
        btnRegister.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                registerUser();
            }
        });

        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                System.exit(0);
            }
        });

        setSize(800, 300); // Adjust frame size for the new layout
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);

        // Populate table with database data on startup
        fetchData();
    }

    private Connection connectToDatabase() {
        // Establish database connection
        String url = "jdbc:mysql://localhost:3307/registration_db"; 
        String user = "root"; 
        String password = "1234"; 
        try {
            return DriverManager.getConnection(url, user, password);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Database connection error: " + e.getMessage());
            return null;
        }
    }

    private void registerUser() {
        // Add user input to the table
        String id = txtID.getText();
        String name = txtName.getText();
        String gender = rbtnMale.isSelected() ? "Male" : rbtnFemale.isSelected() ? "Female" : "";
        String address = txtAddress.getText();
        String contact = txtContact.getText();

        if (!id.isEmpty() && !name.isEmpty() && !gender.isEmpty() && !address.isEmpty() && !contact.isEmpty()) {
            tableModel.addRow(new Object[]{id, name, gender, address, contact});
            JOptionPane.showMessageDialog(this, "Registration Successful!");

            // Save user data to database
            try (Connection conn = connectToDatabase()) {
                if (conn != null) {
                    String sql = "INSERT INTO users (id, name, gender, address, contact) VALUES (?, ?, ?, ?, ?)";
                    PreparedStatement stmt = conn.prepareStatement(sql);

                    stmt.setString(1, id); 
                    stmt.setString(2, name);
                    stmt.setString(3, gender);
                    stmt.setString(4, address);
                    stmt.setString(5, contact);

                    stmt.executeUpdate();
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Error saving to database: " + ex.getMessage());
            }

            // Clear input fields
            txtID.setText("");
            txtName.setText("");
            genderGroup.clearSelection();
            txtAddress.setText("");
            txtContact.setText("");
        } else {
            JOptionPane.showMessageDialog(this, "Please fill in all required fields.");
        }
    }

    private void fetchData() {
        // Fetch user data from database and populate the table
        try (Connection conn = connectToDatabase()) {
            if (conn != null) {
                String sql = "SELECT * FROM users";
                PreparedStatement stmt = conn.prepareStatement(sql);
                ResultSet rs = stmt.executeQuery();

                while (rs.next()) {
                    tableModel.addRow(new Object[]{
                            rs.getString("id"),
                            rs.getString("name"),
                            rs.getString("gender"),
                            rs.getString("address"),
                            rs.getString("contact")
                    });
                }
            }
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error fetching data: " + ex.getMessage());
        }
    }

    public static void main(String[] args) {
        new registrationForm();
    }
}
